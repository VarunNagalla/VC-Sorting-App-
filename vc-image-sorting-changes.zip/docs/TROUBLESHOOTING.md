# Troubleshooting

## The app crashes during folder import

- Install the latest release.
- Process the shoot in batches of 500 or fewer on PC (100 or fewer on iPad/iPhone).
- Close memory-heavy applications.
- Prefer JPEG or WebP previews over extremely large TIFF files.
- Restart the application between very large batches.

The app analyzes faces on a bounded 512-pixel copy to reduce memory use.

## Face model does not load

Use the installed desktop application or `http://127.0.0.1`, not `file:///`.

If developing locally:

```powershell
npm install
npm start
```

Confirm these files exist:

- `models/face_landmarker.task`
- `vendor/mediapipe/vision_bundle.mjs`
- `vendor/mediapipe/wasm/`

## HEIC images do not open

Install HEIF Image Extensions from Microsoft Store or convert the files to JPEG. Browser decoder support varies by Windows installation.

## Save to folder is unavailable

Use **Download ZIP**. Folder selection depends on Chromium's File System Access support and Windows permissions.

## ZIP creation fails

- Reduce the number of selected files.
- Use **Save to folder** for exports near or above 500 MB.
- Confirm enough free disk space is available.

## Windows blocks installation

See [Installation Guide](INSTALLATION.md#Windows-SmartScreen).

## The UI looks outdated

The installed app bundles a fixed version. Install the latest GitHub release.

For browser development, use `Ctrl + Shift + R`.

## Selection looks wrong

AI expression scores are estimates.

- Try a more appropriate selection goal.
- Review **All ranked**.
- Use expression filters.
- Manually override important frames.

Never delete originals solely from an automatic result.
