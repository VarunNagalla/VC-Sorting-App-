# VC Image Sorting 1.0.0

Initial Windows desktop release.

## Features

- Expression-first photo ranking
- Face, eye, blink, gaze, smile, and candid analysis
- Group-photo issue detection
- Face-sharpness and overall-sharpness scoring
- Similar/burst image comparison
- Folder and individual image import
- Expression review filters
- Manual shortlist overrides
- Folder and ZIP export
- Local-only AI processing

## Stability controls

- 500-photo batch limit on PC; 100-photo batch limit on iPad/iPhone
- 512-pixel face-analysis working image
- 720-pixel interface previews
- full-resolution decode cleanup after each image
- 500 MB ZIP safety limit
- per-image face-analysis fallback

## Security

- Electron 42.4.1
- Electron sandbox enabled
- Node integration disabled
- context isolation enabled
- strict Content Security Policy
- no remote scripts, fonts, analytics, or model calls
- loopback-only static server
- navigation and popup blocking
- zero known npm vulnerabilities at release build time

## Windows installer

```text
VC-Image-Sorting-Setup-1.0.0.exe
```

Size:

```text
111959266 bytes
```

SHA-256:

```text
05771EE0ECAE9DEC6897C841935B226732572A34FC479D226FA59770599F016A
```

The installer is not code-signed. Download it only from the official GitHub release and verify the SHA-256 value before running it.
