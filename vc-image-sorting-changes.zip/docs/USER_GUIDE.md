# User Guide

## 1. Choose a selection goal

The goal changes how gaze and expression are interpreted.

- **Personal memories:** favors natural, balanced moments.
- **Candid moments:** allows intentional off-camera gaze and prioritizes authentic interaction.
- **Social media:** favors expressive faces and useful framing.
- **Portfolio:** combines strong expression with stricter technical quality.
- **Profile photo:** strongly favors open eyes, face sharpness, and camera gaze.
- **Just pick the best:** uses expression-first scoring for people and technical scoring otherwise.

## 2. Import images

Use:

- **Add folder** for an entire shoot.
- **Add photos** for selected files.
- Drag and drop a folder or files into the upload area.

For stability, one batch is limited to 500 images on PC and 100 images on iPad/iPhone. Process larger shoots in multiple batches.

Supported formats depend on the browser engine. JPEG, PNG, and WebP are recommended. Some HEIC files may not decode on every Windows configuration.

## 3. Wait for analysis

The app performs local analysis in this order:

1. Detect faces.
2. Inspect eye state and blink likelihood.
3. Evaluate expression and mouth timing.
4. Estimate gaze and candid context.
5. Measure face sharpness.
6. Measure overall technical quality.
7. Compare similar or burst frames.

Full-resolution images are released after analysis. Lightweight previews are used in the interface to reduce memory usage.

## 4. Review results

### Recommended

Shows the current automatic shortlist plus any manually added images.

### All ranked

Shows every analyzed image from strongest to weakest.

### Filtered out

Shows images outside the shortlist or identified as poor expression candidates.

## 5. Expression filters

- **Best expressions**
- **Closed eyes**
- **Blink detected**
- **Good expression, needs editing**
- **Bad expression**
- **Group photo issues**

These filters help photographers review specific problem classes without scanning the entire shoot.

## 6. Understanding labels

- **Best pick: natural expression and open eyes**
- **Reject candidate: closed eyes**
- **Reject candidate: blink detected**
- **Good expression, lighting can be edited**
- **Better face sharpness than other burst shots**
- **Group photo issue: one or more faces have closed eyes**
- **Best pick: natural candid expression**

Scores are decision support, not objective truth. Always review important client images before deleting originals.

## 7. Override a decision

Select the heart control on a photo to add or remove it from the shortlist.

Open **See expression details** to inspect:

- face-expression score
- face sharpness
- eye-open score
- gaze score
- overall sharpness
- exposure
- contrast
- resolution

## 8. Change shortlist size

Use **How selective?**

- Lower percentages produce a tighter shortlist.
- Higher percentages retain more alternatives.

Changing the selection goal or percentage resets manual decisions and recalculates the ranking.

## 9. Export

### Save to folder

Creates a folder named `VC Image Sorting Best Picks` in a location you choose and copies the selected original files.

### Download ZIP

Creates one ZIP file containing the selected originals. For memory safety, very large exports should use **Save to folder**.

## Important workflow advice

- Keep the original shoot until delivery is complete.
- Do not use automatic rejection as an instruction to delete files without review.
- Process extremely large events in logical sections.
- For critical group photos, inspect all faces manually after filtering.
