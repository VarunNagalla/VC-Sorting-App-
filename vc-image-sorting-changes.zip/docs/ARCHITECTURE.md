# Architecture

## Components

```text
Windows executable
  |
  +-- Electron main process
  |     +-- loopback static server
  |     +-- hardened BrowserWindow
  |
  +-- Web application
        +-- import and preview pipeline
        +-- technical image analysis
        +-- face/expression analysis
        +-- burst comparison
        +-- shortlist and filters
        +-- folder/ZIP export
```

## Desktop main process

`desktop/main.cjs` starts a loopback-only HTTP server on a random port and creates a sandboxed Electron window.

The local server exists because browser WebAssembly and module loading are more reliable through an HTTP origin than `file:///`.

## Renderer

`app.js` runs without Node.js access.

It:

- reads user-selected browser `File` objects
- creates bounded analysis canvases
- runs MediaPipe Face Landmarker
- calculates technical image metrics
- creates lightweight preview blobs
- ranks and filters photos
- exports original `File` objects

## Face analysis

Bundled files:

- `models/face_landmarker.task`
- `vendor/mediapipe/vision_bundle.mjs`
- `vendor/mediapipe/wasm/*`

Expression scoring combines:

- eye-open and blink blendshapes
- mouth and smile blendshapes
- gaze and rough head orientation
- face-region sharpness
- group-face weighting
- candid-aware context

## Ranking

When faces exist:

```text
expression > face sharpness > overall sharpness > exposure > other signals
```

When no face exists:

```text
overall sharpness + exposure + contrast + resolution + color + framing
```

Similar images are grouped using:

- dimensions/aspect ratio
- difference hash distance
- filename/burst stem
- file timestamps

Within a face-containing burst, expression issues are compared before technical quality.

## Memory controls

- 500-photo batch limit on PC; 100-photo batch limit on iPad/iPhone
- 512-pixel face-analysis canvas
- 720-pixel interface preview
- immediate release of full-resolution decode references
- 500 MB ZIP limit

## Packaging

`electron-builder` produces a Windows NSIS installer. Large model and WebAssembly files are unpacked from the ASAR archive so the local server can stream them reliably.
