# Security Guide

## Security position

VC Image Sorting is designed to minimize network and desktop attack surface. It is not claimed to be invulnerable. Security depends on the operating system, Electron runtime, bundled third-party libraries, build process, and how installers are distributed.

## Data boundaries

- Photos are selected by the user.
- Photos are processed in the local renderer.
- No application API sends photos or metrics to a remote service.
- No analytics or advertising SDK is included.
- No remote scripts or fonts are loaded.

## Desktop hardening

The Electron window uses:

- `nodeIntegration: false`
- `contextIsolation: true`
- `sandbox: true`
- `webSecurity: true`
- `allowRunningInsecureContent: false`
- hidden application menu
- blocked webviews
- blocked untrusted navigation
- blocked popup creation
- denied browser permissions

## Local server hardening

The desktop application binds only to `127.0.0.1` on a random operating-system-selected port.

The server:

- accepts only `GET` and `HEAD`
- serves only files inside the packaged application root
- rejects path traversal
- does not list directories
- applies strict MIME types
- applies `X-Content-Type-Options: nosniff`
- applies `X-Frame-Options: DENY`
- applies a restrictive Permissions Policy
- applies a restrictive Content Security Policy
- disables caching

## Content Security Policy

The application allows:

- scripts and styles from itself
- local images and user-selected blob/data previews
- local WebAssembly/model requests

It blocks:

- remote scripts
- plugins and objects
- frames
- forms
- arbitrary network connections

Inline CSS values are allowed because progress bars and score meters update their widths dynamically. Inline scripts remain blocked.

## Dependency audit

Before the 1.0.0 build:

```text
npm audit
found 0 vulnerabilities
```

The audit covers known advisories in npm's database at the time it runs. It cannot detect all vulnerabilities or application-logic flaws.

## File handling

- Imports are capped at 500 images per batch on Windows/desktop and 100 images per batch on iPad/iPhone.
- Face analysis uses a bounded 512-pixel working image.
- Temporary full-resolution decode references are released after processing.
- ZIP exports are capped at 500 MB.
- User filenames are escaped before entering generated detail markup.
- Cards use `textContent` for user-provided names and messages.

## Known limitations

- The installer is unsigned and may trigger SmartScreen.
- Local malware with access to the user's account can access selected photos.
- Face-expression analysis is probabilistic and may produce incorrect classifications.
- Media format decoders are part of the Electron/Chromium attack surface.
- npm audit reports known dependency advisories, not unknown vulnerabilities.
- The bundled AI model and runtime increase application size and supply-chain surface.

## Safe use

- Download installers only from the official GitHub repository.
- Verify the SHA-256 hash.
- Keep Windows and the application updated.
- Do not open untrusted image collections from unknown sources on sensitive systems.
- Keep original photos backed up.

## Reporting security issues

Do not publish exploitable security details in a public issue. Contact the repository owner privately through GitHub before public disclosure.

Include:

- application version
- Windows version
- reproduction steps
- affected files or features
- impact assessment
- proof of concept when safe
