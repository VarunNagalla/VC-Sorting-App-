# Testing Guide

## Automated checks

```powershell
npm run check
npm audit
npm run smoke
```

Expected:

- JavaScript syntax succeeds.
- npm reports zero known vulnerabilities.
- Desktop smoke test confirms the UI, AI module, and model load without Node exposure.

## Installer build

```powershell
npm run dist
```

Confirm:

- installer exists
- unpacked application exists
- model and WebAssembly files are included
- SHA-256 can be calculated

## Functional checklist

### Import

- Select individual JPEG images.
- Select a folder.
- Drag and drop a folder.
- Import a folder containing non-image files.
- Import an unsupported image.
- Import more than 500 images on PC (100 on iPad) and confirm the safety limit message.

### Analysis

- Photo with no face.
- Single portrait with open eyes.
- Closed-eye portrait.
- Half-blink frame.
- Natural candid looking away.
- Mid-speech frame.
- Group photo with one closed-eye subject.
- Similar burst with different expressions.

### Ranking

- Confirm expression leads within a burst.
- Confirm face sharpness breaks close expression ties.
- Confirm poor lighting does not automatically reject a great expression.
- Confirm bad expression can reject a technically strong frame.
- Change selection goal and confirm reranking.
- Change selectivity percentage.

### Filters

- Best expressions
- Closed eyes
- Blink detected
- Good expression, needs editing
- Bad expression
- Group photo issues

### Export

- Manually add and remove picks.
- Save picks to a folder.
- Download a small ZIP.
- Confirm ZIP contents are original files.
- Confirm exports do not alter originals.
- Confirm exports over 500 MB request folder export.

### Desktop security

- Attempt navigation to an external page.
- Attempt popup creation.
- Confirm developer webpage has no Node.js access.
- Confirm app binds only to `127.0.0.1`.
- Confirm unknown server paths return 404.
- Confirm traversal paths return 403.

## Regression checklist

- Interface loads without internet.
- Local model loads.
- No Google Fonts or remote scripts are requested.
- Closing and reopening starts a fresh session.
- Memory remains stable across a typical 100-photo batch.
